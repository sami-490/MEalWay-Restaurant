<?php

header('Content-Type: text/plain');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Only process POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); // Method Not Allowed
    echo "Method Not Allowed";
    exit();
}

// Validate required fields
$required_fields = ['name', 'email', 'phone', 'date', 'time', 'people'];
$missing_fields = [];

foreach ($required_fields as $field) {
    if (empty($_POST[$field])) {
        $missing_fields[] = $field;
    }
}

if (!empty($missing_fields)) {
    http_response_code(400);
    echo 'Missing required fields: ' . implode(', ', $missing_fields);
    exit();
}

// Sanitize input data
$name = filter_var(trim($_POST['name']), FILTER_SANITIZE_STRING);
$email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
$phone = filter_var(trim($_POST['phone']), FILTER_SANITIZE_STRING);
$date = trim($_POST['date']);
$time = trim($_POST['time']);
$people = filter_var(trim($_POST['people']), FILTER_SANITIZE_NUMBER_INT);
$message = isset($_POST['message']) ? filter_var(trim($_POST['message']), FILTER_SANITIZE_STRING) : '';

// Validate email format
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo 'Invalid email format';
    exit();
}

// Validate date and time
if (!strtotime($date) || !strtotime($time)) {
    http_response_code(400);
    echo 'Invalid date or time format';
    exit();
}

// Database insertion
try {
    require_once '../config.php';

    $pdo = getDBConnection();

    // Prepare and bind
    $stmt = $pdo->prepare("INSERT INTO reservations (name, email, phone, date, time, people, message) VALUES (?, ?, ?, ?, ?, ?, ?)");

    
    $result = $stmt->execute([$name, $email, $phone, $date, $time, $people, $message]);

    if ($result) {
        
        echo "OK";
    } else {
   
        http_response_code(500);
        echo 'Error saving reservation data.';
        error_log("Failed to insert reservation data into database");
    }

} catch (Exception $e) {
    http_response_code(500);
    echo 'Database error: ' . $e->getMessage();
    error_log("Database error in book-a-table.php: " . $e->getMessage());
}


<?php
/**
 * Handles contact form data submission
 * Stores data in MySQL database
 */

// Set appropriate headers
header('Content-Type: text/plain');


// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Only process POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); // Method Not Allowed
    echo "Method Not Allowed";
    exit();
}

// Validate required fields
$required_fields = ['name', 'email', 'subject', 'message'];
$missing_fields = [];

foreach ($required_fields as $field) {
    if (empty($_POST[$field])) {
        $missing_fields[] = $field;
    }
}

if (!empty($missing_fields)) {
    http_response_code(400);
    echo 'Missing required fields: ' . implode(', ', $missing_fields);
    exit();
}

// Sanitize input data
$name = filter_var(trim($_POST['name']), FILTER_SANITIZE_STRING);
$email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
$subject = filter_var(trim($_POST['subject']), FILTER_SANITIZE_STRING);
$message = filter_var(trim($_POST['message']), FILTER_SANITIZE_STRING);

// Validate email format
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo 'Invalid email format';
    exit();
}

// Database insertion
try {
    require_once '../config.php';

    $pdo = getDBConnection();

    // Prepare and bind
    $stmt = $pdo->prepare("INSERT INTO contacts (name, email, subject, message) VALUES (?, ?, ?, ?)");

    // Execute the statement with form data
    $result = $stmt->execute([$name, $email, $subject, $message]);

    if ($result) {
        // Success response - the JavaScript expects "OK" for success
        echo "OK";
    } else {
        // Error response
        http_response_code(500);
        echo 'Error saving contact data.';
        error_log("Failed to insert contact data into database");
    }

} catch (Exception $e) {
    http_response_code(500);
    echo 'Database error: ' . $e->getMessage();
    error_log("Database error in contact.php: " . $e->getMessage());
}
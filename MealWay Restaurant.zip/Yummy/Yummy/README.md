# Yummy Restaurant - MySQL Database Integration

This project has been configured to connect to a MySQL database for storing reservation and contact form data.

## Setup Instructions

### 1. Configure Database Connection
1. Make sure you have MySQL server running on your system
2. Update the `.env` file in the main directory with your MySQL configuration:
   ```env
   DB_HOST=localhost
   DB_NAME=yummy_restaurant
   DB_USER=your_mysql_username
   DB_PASS=your_mysql_password
   DB_PORT=3306
   ```

### 2. Create Database and Tables
1. Run the setup script to create the database and tables:
   ```
   php setup-database.php
   ```
   Or access it via browser: `http://yoursite.com/setup-database.php`

### 3. Test Database Connection
1. Run the connection test script:
   ```
   php test-connection.php
   ```
   Or access it via browser: `http://yoursite.com/test-connection.php`

### 4. Verify Form Integration
1. The contact form and reservation form now store data in MySQL while maintaining email functionality
2. Form data is saved to:
   - `reservations` table (from book-a-table form)
   - `contacts` table (from contact form)

### 5. Admin Panel
1. Access the admin panel to view stored data:
   ```
   http://yoursite.com/admin.php
   ```

## Files Added

- `.env` - Database configuration
- `config.php` - Database connection and environment loader
- `database.php` - Database utility functions
- `test-connection.php` - Test database connection
- `setup-database.php` - Create database tables
- `admin.php` - Admin panel to view stored data
- Updated `forms/book-a-table.php` - Enhanced with database storage
- Updated `forms/contact.php` - Enhanced with database storage

## Database Schema

### reservations table
- id (INT, AUTO_INCREMENT, PRIMARY KEY)
- name (VARCHAR(100), NOT NULL)
- email (VARCHAR(100), NOT NULL)
- phone (VARCHAR(20), NOT NULL)
- date (DATE, NOT NULL)
- time (TIME, NOT NULL)
- people (INT, NOT NULL)
- message (TEXT)
- created_at (TIMESTAMP, DEFAULT CURRENT_TIMESTAMP)

### contacts table
- id (INT, AUTO_INCREMENT, PRIMARY KEY)
- name (VARCHAR(100), NOT NULL)
- email (VARCHAR(100), NOT NULL)
- subject (VARCHAR(200), NOT NULL)
- message (TEXT, NOT NULL)
- created_at (TIMESTAMP, DEFAULT CURRENT_TIMESTAMP)

### menu_items table (for future use)
- id (INT, AUTO_INCREMENT, PRIMARY KEY)
- category (VARCHAR(50), NOT NULL)
- name (VARCHAR(100), NOT NULL)
- description (TEXT)
- price (DECIMAL(10, 2), NOT NULL)
- image (VARCHAR(255))
- created_at (TIMESTAMP, DEFAULT CURRENT_TIMESTAMP)

## Troubleshooting

1. **Connection Error**: Make sure MySQL server is running and credentials in `.env` are correct
2. **Database doesn't exist**: Run `setup-database.php` to create the database
3. **Forms not saving**: Verify that `config.php` can be included and database connection works
4. **Access denied**: Check your MySQL user permissions

## Security Notes

1. Make sure your `.env` file is not accessible from the web
2. Use strong passwords for database users
3. Consider using prepared statements for all database queries
4. Sanitize and validate all input before storing in database
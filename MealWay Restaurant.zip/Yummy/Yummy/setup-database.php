<?php
require_once 'config.php';

echo "<h2>Yummy Restaurant - Database Setup</h2>\n";

try {
    $pdo = getDBConnection();
    $dbName = DB_NAME;
    
    // Use the database
    $pdo->query("USE `$dbName`");
    
    // Create reservations table
    $reservationsTable = "
    CREATE TABLE IF NOT EXISTS reservations (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL,
        phone VARCHAR(20) NOT NULL,
        date DATE NOT NULL,
        time TIME NOT NULL,
        people INT NOT NULL,
        message TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    $pdo->exec($reservationsTable);
    echo "<p style='color: green;'>✓ Reservations table created successfully!</p>\n";
    
    // Create contacts table
    $contactsTable = "
    CREATE TABLE IF NOT EXISTS contacts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL,
        subject VARCHAR(200) NOT NULL,
        message TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    $pdo->exec($contactsTable);
    echo "<p style='color: green;'>✓ Contacts table created successfully!</p>\n";
    
    // Create menu_items table (for future use)
    $menuTable = "
    CREATE TABLE IF NOT EXISTS menu_items (
        id INT AUTO_INCREMENT PRIMARY KEY,
        category VARCHAR(50) NOT NULL,
        name VARCHAR(100) NOT NULL,
        description TEXT,
        price DECIMAL(10, 2) NOT NULL,
        image VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    $pdo->exec($menuTable);
    echo "<p style='color: green;'>✓ Menu items table created successfully!</p>\n";
    
    // Show table information
    echo "<h3>Database tables created:</h3>\n";
    echo "<ul>\n";
    echo "<li>reservations - for storing table reservation data</li>\n";
    echo "<li>contacts - for storing contact form submissions</li>\n";
    echo "<li>menu_items - for storing menu information (future use)</li>\n";
    echo "</ul>\n";
    
    echo "<p style='color: green;'>✓ Database setup completed successfully!</p>\n";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>✗ Error during database setup: " . htmlspecialchars($e->getMessage()) . "</p>\n";
}
?>
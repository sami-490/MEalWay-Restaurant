<?php
// test-connection.php - Script to test MySQL database connection

require_once 'config.php';

echo "<h2>Yummy Restaurant - MySQL Connection Test</h2>\n";

try {
    $pdo = getDBConnection();
    echo "<p style='color: green;'>✓ Successfully connected to MySQL database!</p>\n";
    echo "<p>Connected to database: <strong>" . DB_NAME . "</strong></p>\n";
    echo "<p>Host: <strong>" . DB_HOST . "</strong></p>\n";
    echo "<p>User: <strong>" . DB_USER . "</strong></p>\n";
    
    // Check if database exists and create if it doesn't
    try {
        // Check if database exists
        $dbName = DB_NAME;
        $result = $pdo->query("SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '$dbName'");
        
        if ($result->rowCount() == 0) {
            // Create the database
            $pdo->query("CREATE DATABASE IF NOT EXISTS `$dbName` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            $pdo->query("USE `$dbName`");
            echo "<p style='color: orange;'>• Database '$dbName' was created.</p>\n";
        } else {
            $pdo->query("USE `$dbName`");
            echo "<p style='color: green;'>✓ Database '$dbName' exists and is ready to use.</p>\n";
        }
        
        echo "<p style='color: green;'>✓ Connection test completed successfully!</p>\n";
    } catch (PDOException $e) {
        echo "<p style='color: red;'>✗ Error managing database: " . htmlspecialchars($e->getMessage()) . "</p>\n";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>✗ Could not connect to MySQL database:</p>\n";
    echo "<p style='color: red;'>" . htmlspecialchars($e->getMessage()) . "</p>\n";
    echo "<p>Please check your .env file configuration.</p>\n";
}

echo "<h3>Current Configuration:</h3>\n";
echo "<ul>\n";
echo "<li>Host: " . htmlspecialchars(DB_HOST) . "</li>\n";
echo "<li>Database: " . htmlspecialchars(DB_NAME) . "</li>\n";
echo "<li>User: " . htmlspecialchars(DB_USER) . "</li>\n";
echo "<li>Port: " . htmlspecialchars(DB_PORT) . "</li>\n";
echo "</ul>\n";

echo "<p><strong>Note:</strong> Make sure MySQL server is running on your system.</p>\n";
?>
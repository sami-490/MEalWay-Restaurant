<?php
// database.php - Advanced database utility functions

require_once 'config.php';

class DatabaseManager {
    private $pdo;
    
    public function __construct() {
        $this->pdo = getDBConnection();
    }
    
    // Function to get all reservations
    public function getAllReservations() {
        try {
            $stmt = $this->pdo->query("SELECT * FROM reservations ORDER BY created_at DESC");
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error fetching reservations: " . $e->getMessage());
            return [];
        }
    }
    
    // Function to get reservation by ID
    public function getReservationById($id) {
        try {
            $stmt = $this->pdo->prepare("SELECT * FROM reservations WHERE id = ?");
            $stmt->execute([$id]);
            return $stmt->fetch();
        } catch (Exception $e) {
            error_log("Error fetching reservation: " . $e->getMessage());
            return null;
        }
    }
    
    // Function to add a new reservation
    public function addReservation($name, $email, $phone, $date, $time, $people, $message = '') {
        try {
            $stmt = $this->pdo->prepare("INSERT INTO reservations (name, email, phone, date, time, people, message) VALUES (?, ?, ?, ?, ?, ?, ?)");
            return $stmt->execute([$name, $email, $phone, $date, $time, $people, $message]);
        } catch (Exception $e) {
            error_log("Error adding reservation: " . $e->getMessage());
            return false;
        }
    }
    
    // Function to get all contacts
    public function getAllContacts() {
        try {
            $stmt = $this->pdo->query("SELECT * FROM contacts ORDER BY created_at DESC");
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error fetching contacts: " . $e->getMessage());
            return [];
        }
    }
    
    // Function to get contact by ID
    public function getContactById($id) {
        try {
            $stmt = $this->pdo->prepare("SELECT * FROM contacts WHERE id = ?");
            $stmt->execute([$id]);
            return $stmt->fetch();
        } catch (Exception $e) {
            error_log("Error fetching contact: " . $e->getMessage());
            return null;
        }
    }
    
    // Function to add a new contact
    public function addContact($name, $email, $subject, $message) {
        try {
            $stmt = $this->pdo->prepare("INSERT INTO contacts (name, email, subject, message) VALUES (?, ?, ?, ?)");
            return $stmt->execute([$name, $email, $subject, $message]);
        } catch (Exception $e) {
            error_log("Error adding contact: " . $e->getMessage());
            return false;
        }
    }
    
    // Function to get all menu items
    public function getAllMenuItems() {
        try {
            $stmt = $this->pdo->query("SELECT * FROM menu_items ORDER BY category, name");
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error fetching menu items: " . $e->getMessage());
            return [];
        }
    }
    
    // Function to add a new menu item
    public function addMenuItem($category, $name, $description, $price, $image = null) {
        try {
            $stmt = $this->pdo->prepare("INSERT INTO menu_items (category, name, description, price, image) VALUES (?, ?, ?, ?, ?)");
            return $stmt->execute([$category, $name, $description, $price, $image]);
        } catch (Exception $e) {
            error_log("Error adding menu item: " . $e->getMessage());
            return false;
        }
    }
}
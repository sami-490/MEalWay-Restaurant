<?php


$baseUrl = 'http://localhost/Yummy/Yummy/forms/';

function testForm($url, $data, $formName) {
    echo "Testing $formName...\n";
    
    $options = [
        'http' => [
            'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
            'method'  => 'POST',
            'content' => http_build_query($data),
            'ignore_errors' => true
        ]
    ];
    
    $context  = stream_context_create($options);
    $result = file_get_contents($url, false, $context);
    
    // Check for exact match "OK"
    if ($result === 'OK') {
        echo "PASS: $formName returned exactly 'OK'.\n";
    } else {
        echo "FAIL: $formName returned something else.\n";
        echo "Length: " . strlen($result) . "\n";
        echo "Content: '" . $result . "'\n";
        echo "Hex: " . bin2hex($result) . "\n";
    }
    echo "--------------------------------------------------\n";
}

// Test Contact Form
$contactData = [
    'name' => 'Test User',
    'email' => 'test@example.com',
    'subject' => 'Test Subject',
    'message' => 'Test Message'
];
testForm($baseUrl . 'contact.php', $contactData, 'Contact Form');

// Test Book a Table Form
$bookData = [
    'name' => 'Test Booker',
    'email' => 'booker@example.com',
    'phone' => '1234567890',
    'date' => date('Y-m-d', strtotime('+1 day')),
    'time' => '19:00',
    'people' => 4,
    'message' => 'Test Booking'
];
testForm($baseUrl . 'book-a-table.php', $bookData, 'Book a Table Form');

?>

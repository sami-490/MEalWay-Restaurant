<?php
// admin.php - Administration page to view reservations and contacts

require_once 'database.php';

$db = new DatabaseManager();

// Set content type to HTML
header('Content-Type: text/html; charset=utf-8');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yummy Admin Panel</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #2c3e50;
            text-align: center;
            margin-bottom: 30px;
        }
        .section {
            margin-bottom: 40px;
        }
        h2 {
            color: #3498db;
            border-bottom: 2px solid #3498db;
            padding-bottom: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f8f9fa;
            font-weight: bold;
        }
        tr:hover {
            background-color: #f5f5f5;
        }
        .no-data {
            text-align: center;
            padding: 20px;
            color: #777;
        }
        .timestamp {
            font-size: 0.85em;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Yummy Restaurant - Admin Panel</h1>
        
        <div class="section">
            <h2>Recent Reservations</h2>
            <?php
            $reservations = $db->getAllReservations();
            if (!empty($reservations)) {
                echo '<table>';
                echo '<tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Date</th><th>Time</th><th>People</th><th>Message</th><th>Created At</th></tr>';
                foreach ($reservations as $reservation) {
                    echo '<tr>';
                    echo '<td>' . htmlspecialchars($reservation['id']) . '</td>';
                    echo '<td>' . htmlspecialchars($reservation['name']) . '</td>';
                    echo '<td>' . htmlspecialchars($reservation['email']) . '</td>';
                    echo '<td>' . htmlspecialchars($reservation['phone']) . '</td>';
                    echo '<td>' . htmlspecialchars($reservation['date']) . '</td>';
                    echo '<td>' . htmlspecialchars($reservation['time']) . '</td>';
                    echo '<td>' . htmlspecialchars($reservation['people']) . '</td>';
                    echo '<td>' . htmlspecialchars($reservation['message']) . '</td>';
                    echo '<td class="timestamp">' . htmlspecialchars($reservation['created_at']) . '</td>';
                    echo '</tr>';
                }
                echo '</table>';
            } else {
                echo '<p class="no-data">No reservations found.</p>';
            }
            ?>
        </div>
        
        <div class="section">
            <h2>Recent Contacts</h2>
            <?php
            $contacts = $db->getAllContacts();
            if (!empty($contacts)) {
                echo '<table>';
                echo '<tr><th>ID</th><th>Name</th><th>Email</th><th>Subject</th><th>Message</th><th>Created At</th></tr>';
                foreach ($contacts as $contact) {
                    echo '<tr>';
                    echo '<td>' . htmlspecialchars($contact['id']) . '</td>';
                    echo '<td>' . htmlspecialchars($contact['name']) . '</td>';
                    echo '<td>' . htmlspecialchars($contact['email']) . '</td>';
                    echo '<td>' . htmlspecialchars($contact['subject']) . '</td>';
                    echo '<td>' . htmlspecialchars($contact['message']) . '</td>';
                    echo '<td class="timestamp">' . htmlspecialchars($contact['created_at']) . '</td>';
                    echo '</tr>';
                }
                echo '</table>';
            } else {
                echo '<p class="no-data">No contacts found.</p>';
            }
            ?>
        </div>
    </div>
</body>
</html>